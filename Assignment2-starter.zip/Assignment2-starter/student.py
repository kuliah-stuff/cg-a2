"""Implement the tasks described in the Assignment 2 PDF.

Only this file is submitted. Do not change the function signatures.
Read the conventions at the top of halfedge.py before starting.
"""

import numpy as np

from halfedge import HalfedgeMesh


# Task 1: traversal

def face_halfedges(face):
    """Task 1. Return the halfedges of the face loop, starting at face.halfedge."""
    raise NotImplementedError('Task 1: face_halfedges')


def face_vertices(face):
    """Task 1. Return the target vertices of face_halfedges(face), in the same order."""
    raise NotImplementedError('Task 1: face_vertices')


def vertex_halfedges(vertex):
    """Task 1. Return the outgoing halfedges of the vertex, starting at vertex.halfedge."""
    raise NotImplementedError('Task 1: vertex_halfedges')


def vertex_neighbors(vertex):
    """Task 1. Return the neighboring vertices, in the order of vertex_halfedges(vertex)."""
    raise NotImplementedError('Task 1: vertex_neighbors')


def vertex_faces(vertex):
    """Task 1. Return the adjacent interior faces, in the order of vertex_halfedges(vertex)."""
    raise NotImplementedError('Task 1: vertex_faces')


def is_boundary_vertex(vertex):
    """Task 1. Return True if the vertex lies on a boundary loop."""
    raise NotImplementedError('Task 1: is_boundary_vertex')


# Task 2: face geometry

def face_centroid(face):
    """Task 2. Return the average of the face vertex positions, shape (3,)."""
    raise NotImplementedError('Task 2: face_centroid')


def face_normal(face):
    """Task 2. Return the unit normal from Newell's method, shape (3,)."""
    raise NotImplementedError('Task 2: face_normal')


def face_area(face):
    """Task 2. Return the area of the planar polygon as a float."""
    raise NotImplementedError('Task 2: face_area')


# Task 3: mesh summary

def mesh_summary(mesh):
    """Task 3. Return a dict with the keys listed in the PDF."""
    raise NotImplementedError('Task 3: mesh_summary')


# Task 4: edge flip

def flip_edge(mesh, edge):
    """Task 4. Flip an interior edge between two triangles in place and return it."""
    raise NotImplementedError('Task 4: flip_edge')


# Task 5: linear subdivision

def subdivide_linear(mesh):
    """Task 5. Return a new HalfedgeMesh after one step of linear subdivision."""
    raise NotImplementedError('Task 5: subdivide_linear')


# Task 6: Catmull-Clark subdivision

def subdivide_catmull_clark(mesh):
    """Task 6. Return a new HalfedgeMesh after one Catmull-Clark step on a closed mesh."""
    raise NotImplementedError('Task 6: subdivide_catmull_clark')
